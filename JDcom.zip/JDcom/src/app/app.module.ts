import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpModule,JsonpModule} from "@angular/http";
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';

import { HomePage } from '../pages/home/home';
import { CategoryPage } from '../pages/category/category';
import { CartPage } from '../pages/cart/cart';

import { UserPage } from '../pages/user/user';

import { LoginPage } from '../pages/login/login';
import { RegisterPage } from '../pages/register/register';
import { RegisterpasswordPage } from '../pages/registerpassword/registerpassword';
import { RegistersignPage } from '../pages/registersign/registersign';
import { SearchPage } from '../pages/search/search';
import { ProductlistPage } from '../pages/productlist/productlist';
import { ProductdetailPage } from '../pages/productdetail/productdetail';
import { PersonalPage } from '../pages/personal/personal';
import { OrderPage } from "../pages/order/order";
import { AddAddressPage } from '../pages/add-address/add-address';
import { AddressPage } from '../pages/address/address';
import { EditAddressPage } from '../pages/edit-address/edit-address';
import { PaymentPage } from '../pages/payment/payment';


import { TabsPage } from '../pages/tabs/tabs';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { ConfigProvider } from '../providers/config/config';
import { HttpServiceProvider } from '../providers/http-service/http-service';
import { StorageProvider } from '../providers/storage/storage';
import { UtilsProvider } from '../providers/utils/utils';



@NgModule({
  declarations: [
    MyApp,
    CategoryPage,
    CartPage,
    UserPage,
    HomePage,
    TabsPage,
    LoginPage,
    RegisterPage,
    RegisterpasswordPage,
    RegistersignPage,
    SearchPage,
    ProductlistPage,
    ProductdetailPage,
    PersonalPage,
    OrderPage,
    AddressPage,
    AddAddressPage,
    EditAddressPage,
    PaymentPage
  ],
  imports: [
    BrowserModule,
    HttpModule,
    JsonpModule,
    IonicModule.forRoot(MyApp,{
      tabsHideOnSubPages: 'true', //隐藏全部子页面 tabs
      backButtonText: '' /*配置返回按钮*/
    })
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    CategoryPage,
    CartPage,
    UserPage,
    HomePage,
    TabsPage,
    LoginPage,
    RegisterPage,
    RegisterpasswordPage,
    RegistersignPage,
    SearchPage,
    ProductlistPage,
    ProductdetailPage,
    PersonalPage,
    OrderPage,
    AddressPage,
    AddAddressPage,
    EditAddressPage,
    PaymentPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    ConfigProvider,
    HttpServiceProvider,
    StorageProvider,
    UtilsProvider
  ]
})
export class AppModule {}
