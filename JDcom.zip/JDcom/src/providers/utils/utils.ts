import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { StorageProvider } from '../storage/storage';
import { Md5 } from 'ts-md5/dist/md5';

/*
  Generated class for the UtilsProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class UtilsProvider {

  constructor(public http: Http, public storage: StorageProvider) {
    console.log('Hello UtilsProvider Provider');
  }

  getUserInfo(){
    let userinfo = this.storage.get('userinfo');
    return userinfo;
  }

  sign(data){
    let tempArr = [];
    for (let attr in data) {
      tempArr.push(attr);     
    }
    tempArr = tempArr.sort();
    let temStr = '';
    for (let index = 0; index < tempArr.length; index++) {
     temStr += tempArr[index]+data[tempArr[index]];    
    }
    return Md5.hashStr(temStr);
  }

}
