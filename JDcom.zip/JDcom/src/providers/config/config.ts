import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';

/*
  Generated class for the ConfigProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class ConfigProvider {

  public serverAddress = 'http://39.108.159.135/';

  constructor(public http: Http) {
    console.log('Hello ConfigProvider Provider');
  }

  run(){
    console.log('run provider');
  }

}
