import {Injectable} from '@angular/core';
import {Http, Jsonp, Headers} from '@angular/http';
import 'rxjs/add/operator/map';
import {ConfigProvider} from '../config/config';

/*
  Generated class for the HttpServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class HttpServiceProvider {
  private headers = new Headers({'Content-Type': 'application/json'});
  constructor(public http : Http, public jsonp : Jsonp, public config : ConfigProvider) {
    console.log('Hello HttpServiceProvider Provider');
  }

  request(apiUrl, callback) {
    let api = '';
    if (apiUrl.indexOf('?') == -1) {
      api = this.config.serverAddress + apiUrl + '?callback=JSONP_CALLBACK';
    } else {
      api = this.config.serverAddress + apiUrl + '&callback=JSONP_CALLBACK';
    }
    this
      .jsonp
      .get(api)
      .subscribe((data) => {
        callback(data);
      }),
    (err) => {}
  }

  post(apiUrl, data, callback) {
    let api = this.config.serverAddress + apiUrl;
    this
      .http
      .post(api, JSON.stringify(data), {headers: this.headers})
      .subscribe((res) => {
        callback(res.json());
      });
  }

}
