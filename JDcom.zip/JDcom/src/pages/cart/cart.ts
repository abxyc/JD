import { Component } from '@angular/core';
import { NavController ,ToastController} from 'ionic-angular';
import { StorageProvider } from "../../providers/storage/storage";
import { ConfigProvider } from "../../providers/config/config";
import { OrderPage } from "../order/order";

@Component({
  selector: 'page-cart',
  templateUrl: 'cart.html'
})
export class CartPage {

  public carts = [];
  public sumPrice = 0;
  public ischecked = false;
  public isEdit = false;
  public hasData = true;

  constructor(public navCtrl: NavController, public storage: StorageProvider,
     public config: ConfigProvider,public toastCtrl: ToastController) {
  }

  ionViewDidEnter(){
    this.getCartsData();
    let sum = this.getCheckedNum();
    if(sum==this.carts.length&&this.carts.length!==0){
      this.ischecked = true;
      this.hasData = true;
    } else{
      this.ischecked = false;
      this.hasData =false;
    }
    console.log(this.isEdit);
  }

  getCartsData(){
    let cartsData = this.storage.get('carts_data');
    if(cartsData){
      this.carts = cartsData;
      this.hasData = true;
    } else{
      this.carts =[];
      this.hasData = false;
    }
    this.calculatePrice();
  }

  updateStatus(){
   let sum = this.getCheckedNum();
    if(sum==this.carts.length &&this.carts.length!==0){
      this.ischecked = true;
    } else{
      this.ischecked = false;
    }
    this.calculatePrice();
 
  }

  calculatePrice(){
    let tempPrice =0;
    for (let index = 0; index < this.carts.length; index++) {
      if(this.carts[index].checked){
        tempPrice += this.carts[index].product_price*this.carts[index].product_count;
      }
      
    }

    this.sumPrice = tempPrice;
    console.log(this.sumPrice);
  }

  incCount(item){
    item.product_count++;
    this.calculatePrice();
  }
  decCount(item){
    if ( item.product_count >1) {
      item.product_count--;
      this.calculatePrice();
    }
  }
 
  ionViewWillLeave(){
   this.storage.set('carts_data',this.carts)
   
  }

  settleAccount(){
    let tempCartsData = [];
    for (let index = 0; index < this.carts.length; index++) {
      if(this.carts[index].checked){
        tempCartsData.push(this.carts[index]);    
      }  
    }
    if (tempCartsData.length>0) {
      this.storage.set('order_data',tempCartsData); 
      this.navCtrl.push(OrderPage);    
    } else {
      let toast = this.toastCtrl.create({
        message: '您还没有选中商品',
        duration: 3000,
        position: 'top'
      });
    
      toast.onDidDismiss(() => {
        console.log('Dismissed toast');
      });
    
      toast.present();
      
    }
  }

  checkAll(){
    if(this.ischecked){
      for (let index = 0; index < this.carts.length; index++) {
       this.carts[index].checked = false;
        
      }
      this.ischecked =false;
    } else{
      for (let index = 0; index < this.carts.length; index++) {
        this.carts[index].checked = true;
         
       }
       this.ischecked = true;
    }
  }


  getCheckedNum(){
    let sum = 0;
    for (let index = 0; index < this.carts.length; index++) {
      if(this.carts[index].checked){
        sum +=1;
      }
      
    }
    return sum;
  }

  delete(){
    let unCheckArr =[];
    for (let index = 0; index < this.carts.length; index++) {
      if(!this.carts[index].checked){
        unCheckArr.push(this.carts[index]);
      }
      
    }

    this.carts = unCheckArr;
    this.carts.length >0?this.hasData = true: this.hasData =false;
    if (this.carts.length ==0) {
      this.ischecked = false
    }

    this.storage.set('carts_data',unCheckArr);
  }

}
