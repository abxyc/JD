import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { HttpServiceProvider } from '../../providers/http-service/http-service';
import { StorageProvider } from '../../providers/storage/storage';
import { OrderPage } from '../order/order';

/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

  public userinfo ={
    username:'',
    password: ''
  }

  public history = '';

  constructor(public navCtrl: NavController, public navParams: NavParams, public httpService : HttpServiceProvider, public storage: StorageProvider) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
    this.history = this.navParams.get('history');
  }

  login(){
    if(this.userinfo.username.length <6){
      alert("用户名不合法");
    } else{
      this.httpService.post('api/doLogin',this.userinfo, (result)=>{
        if(result.success){
         this.storage.set('userinfo',result.userinfo[0]);
         if(this.history){
           this.navCtrl.push(OrderPage);
         } else{
          this.navCtrl.popToRoot();
         }
        } else{
          alert(result.message);
        }
      });
    }
  }

}
