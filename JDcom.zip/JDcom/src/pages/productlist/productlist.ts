import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ConfigProvider } from '../../providers/config/config';
import { HttpServiceProvider } from '../../providers/http-service/http-service';
/**
 * Generated class for the ProductlistPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-productlist',
  templateUrl: 'productlist.html',
})
export class ProductlistPage {

  public reclist = [];
  public cid ='';
  public page = 1;

  constructor(public navCtrl: NavController, public navParams: NavParams, public config: ConfigProvider, public httpService: HttpServiceProvider) {
    this.cid =  this.navParams.get('cid');
    this.getProductList('');
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ProductlistPage');
  }

  getProductList(infiniteScroll){
    this.httpService.request(`api/plist?cid=${this.cid}&page=${this.page}`,(data)=>{
      this.reclist = this.reclist.concat(data['_body'].result);
      if(infiniteScroll){
        infiniteScroll.complete();
        if(data['_body'].result.length <10){
          infiniteScroll.enable(false);
        }
      }
      this.page ++;
    });
  }

  doLoadMore(infiniteScroll){
    this.getProductList(infiniteScroll);
  }

}
