import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams,ToastController } from 'ionic-angular';
import { HttpServiceProvider } from '../../providers/http-service/http-service';
import { UtilsProvider } from '../../providers/utils/utils';
import { AddressPage } from '../address/address';



/**
 * Generated class for the AddAddressPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-add-address',
  templateUrl: 'add-address.html',
})
export class AddAddressPage {
  public addressList = {
    name: '',
    phone: '',
    address: ''
  }
  public AddressPage = AddressPage;

  constructor(public navCtrl: NavController, public navParams: NavParams, public utils: UtilsProvider, public httpService: HttpServiceProvider,public toastCtrl:ToastController ) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AddAddressPage');
  }

  addAddress(){
    if (this.addressList.address!==''&&this.addressList.name!==''&&this.addressList.phone!=='') {
    let userinfo = this.utils.getUserInfo();
    let data = {
      uid: userinfo._id,
      salt:userinfo.salt,
      name: this.addressList.name,
      phone: this.addressList.phone,
      address: this.addressList.address
    }

    let sign = this.utils.sign(data);
    let api = 'api/addAddress';
    this.httpService.post(api,
      {
        uid: userinfo._id,
        sign:sign,
        name: this.addressList.name,
        phone: this.addressList.phone,
        address: this.addressList.address
      },(data)=>{
        console.log(data);
      }
    );
    } else {
      let toast = this.toastCtrl.create({
        message: '收货地址不对',
        duration: 3000,
        position: 'top'
      });
    
      toast.onDidDismiss(() => {
        console.log('Dismissed toast');
      });
    
      toast.present();
      
    }  
    
  }

}
