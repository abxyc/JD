import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { StorageProvider } from '../../providers/storage/storage';
import { LoginPage } from '../login/login';
import { ConfigProvider } from '../../providers/config/config';
import { HttpServiceProvider } from '../../providers/http-service/http-service';
import { UtilsProvider } from '../../providers/utils/utils';
import { AddressPage } from '../address/address';
import { PaymentPage } from '../payment/payment';

/**
 * Generated class for the OrderPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-order',
  templateUrl: 'order.html',
})
export class OrderPage {

  public orderList = [];
  public userinfo;
  public LoginPage = LoginPage;
  public AddressPage = AddressPage;
  public address:any;
  public allPrice :any;
  public leave_word:any;

  constructor(public navCtrl: NavController, 
              public navParams: NavParams,
              public storage: StorageProvider,
              public config:ConfigProvider,
              public httpService:HttpServiceProvider,
              public utils: UtilsProvider,
              public toastCtrl:ToastController) {
                this.userinfo =  this.utils.getUserInfo();
  }

  ionViewDidLoad() {

  }
  
  ionViewDidEnter(){
    let userinfo = this.utils.getUserInfo();
    this.orderList = this.storage.get('order_data');
    if(this.userinfo){
      this.getDefaultAddress();
    }
    this.calculatePrice();
  }

  getDefaultAddress() {

    //获取签名
    let userinfo:any=this.userinfo;

    let json={
      uid:userinfo['_id'],
      salt:userinfo.salt
    }
    let sign=this.utils.sign(json);

    //请求数据
    let api='api/oneAddressList?uid='+userinfo['_id']+'&sign='+sign;

    this.httpService.request(api,(data)=>{

      // console.log(data);
      if(data.ok){

        console.log(data.result);

        // this.address=''
        this.address=data['_body'].result[0];
        
      }else{
        this.address=''

      }

    })
  }

  pay(){
    let data:any;
    // data ={
    //   uid: this.userinfo._id,
    //    id:this.address._id,
    //    salt: this.userinfo.salt,
    //   address:this.address.address,  
    //   phone:this.address.phone,   
    //   name: this.address.name,     
    //   all_price:this.allPrice,  
    //   products:  JSON.stringify(this.orderList),
    //   leave_word:JSON.stringify(this.leave_word)
    //  }

    if(!this.userinfo){
      this.navCtrl.push(LoginPage,{
        history: 'order'
      });
    } else if(!this.address){
      let toast = this.toastCtrl.create({
        message: '没有选择收货地址',
        duration: 3000,
        position: 'top'
      });
    
      toast.onDidDismiss(() => {
        console.log('Dismissed toast');
      });
    
      toast.present();
    } else{
      data ={
        uid: this.userinfo._id,
        salt: this.userinfo.salt,
        address:this.address.address,  
        phone:this.address.phone,   
        name: this.address.name,     
        all_price:this.allPrice
       }

     let sign = this.utils.sign(data);
     let api = 'api/doOrder';
     this.httpService.post(api,{
        uid: this.userinfo._id,
         salt: this.userinfo.salt,
        address:this.address.address,  
        phone:this.address.phone,   
        name: this.address.name,     
        all_price:this.allPrice,
        sign:sign,
        products: JSON.stringify(this.orderList),
       },(rslt)=>{
         this.navCtrl.push(PaymentPage);

     })

    }


}

  calculatePrice(){
    let tempPrice =0;
    for (let index = 0; index < this.orderList.length; index++) {
      if(this.orderList[index].checked){
        tempPrice += this.orderList[index].product_price*this.orderList[index].product_count;
      }
      
    }

    this.allPrice = tempPrice;
    console.log(this.allPrice);
  }

}
