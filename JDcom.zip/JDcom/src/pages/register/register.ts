import {Component} from '@angular/core';
import {IonicPage, NavController, NavParams} from 'ionic-angular';

import {RegistersignPage} from '../registersign/registersign';
import {ConfigProvider} from '../../providers/config/config';
import {HttpServiceProvider} from '../../providers/http-service/http-service';
import { StorageProvider } from '../../providers/storage/storage';

/**
 * Generated class for the RegisterPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({selector: 'page-register', templateUrl: 'register.html'})
export class RegisterPage {
  public tel = '';
  constructor(public navCtrl : NavController, public navParams : NavParams, public config : ConfigProvider, public httpService : HttpServiceProvider, public storage: StorageProvider) {}

  ionViewDidLoad() {
    console.log('ionViewDidLoad RegisterPage');
  }

  goRegistersignPage() {
    if (/^\d{11}$/.test(this.tel)) {
      this.httpService.post('api/sendCode', {'tel': this.tel}, (rslt) => {
          if (rslt.success) {
            console.log(rslt);
            this.navCtrl.push(RegistersignPage);
            this.storage.set('tel',this.tel);
          } else {
            alert('发送验证码失败'+' ' + rslt.message);
          }

        });
    } else{
      alert('电话号码不正确');
    }
  }

}
