import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { SearchPage } from '../search/search';
import { ProductdetailPage } from '../productdetail/productdetail';
import { ConfigProvider } from '../../providers/config/config';
import { HttpServiceProvider } from '../../providers/http-service/http-service';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  public reclist = [];
  public reclistWidth = ''; 
  public carouselList = [];
  public keenList = [];
  public ProductdetailPage = ProductdetailPage;
  constructor(public navCtrl: NavController, public config: ConfigProvider, public httpService:HttpServiceProvider ) {
    this.getCarseousel();
    this.getRecommendedList();
    this.getKeenList();
  }

  ionViewDidLoad(){

  }

  goSearch(){
    this.navCtrl.push(SearchPage);
  }

  getCarseousel(){
    this.httpService.request('api/focus',(data)=>{
      this.carouselList = data['_body'].result;
    });
  }

  getRecommendedList(){
    this.httpService.request('api/plist?is_best=1',(data)=>{
      this.reclist = data['_body'].result;
      this.reclistWidth = this.reclist.length * 92 + 'px';
    });
  }

  getKeenList(){
    this.httpService.request('api/plist?is_hot=1',(data)=>{
      this.keenList = data['_body'].result;
    });

  }
}
