import {Component} from '@angular/core';
import {NavController} from 'ionic-angular';
import {ConfigProvider} from '../../providers/config/config';
import {HttpServiceProvider} from '../../providers/http-service/http-service';
import {ProductlistPage  } from '../productlist/productlist';
@Component({selector: 'page-category', templateUrl: 'category.html'})
export class CategoryPage {

  public selectId = ''; 

  public leftCateList = [];
  public rightCateList = [];

  public ProductlistPage = ProductlistPage;

  constructor(public navCtrl : NavController, public config : ConfigProvider, public httpService : HttpServiceProvider) {
    this.getLeftCateList();
  }

  ionViewDidLoad(){
  }

  getLeftCateList() {
    let api = 'api/pcate';
    this
      .httpService
      .request(api, (data) => {
        this.leftCateList = data['_body'].result;
        this.getRightCateList(this.leftCateList[0]['_id'])
      });

  }

  getRightCateList(pid){
    this.selectId = pid;
    let api = `api/pcate?pid=${pid}`;
    this
      .httpService
      .request(api, (data) => {
        this.rightCateList = data['_body'].result;
      });
  }
}
