import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams, Content,AlertController } from 'ionic-angular';
import { ConfigProvider } from '../../providers/config/config';
import { HttpServiceProvider } from '../../providers/http-service/http-service';
import { StorageProvider } from '../../providers/storage/storage';

/**
 * Generated class for the SearchPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-search',
  templateUrl: 'search.html',
})
export class SearchPage {
  @ViewChild(Content) content: Content;

  public flag = false;
  public reclist = [];
  public keyWord = '';
  public page = 1;
  public hasData = true;
  public historyList = [];

  constructor(public navCtrl: NavController, 
     public navParams: NavParams, 
     public config:ConfigProvider,
     public httpService:HttpServiceProvider,
     public storage: StorageProvider,
    public alertCtrl: AlertController ) {
   this.getHistory();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SearchPage');
  }

  getSearchList(infiniteScroll){
    if (!infiniteScroll) {
      this.page =1;
      this.hasData = true;
      this.content.scrollToTop(0);
      if(this.keyWord&&this.keyWord !==''){
        this.saveHistory();
      }

    }
    let api = `api/plist?search=${this.keyWord}&page=${this.page}`;
    this.httpService.request(api,(data)=>{
      if(this.page ==1){
        this.reclist = data['_body'].result;
      } else{
        this.reclist = this.reclist.concat(data['_body'].result);
      }
      this.flag = true;
      if(infiniteScroll){
        infiniteScroll.complete();
        if(data['_body'].result.length <10){
          this.hasData = false;

        }
      }
      this.page ++;
    });
  }

  doLoadMore(infiniteScroll){
    this.getSearchList(infiniteScroll);
  }

  goSearch(item){
    this.keyWord = item;
    this.getSearchList('');

  }

  saveHistory(){
    let history =  this.storage.get('historyData');
    if (history) {
      if (history.indexOf(this.keyWord)==-1) {
        history.push(this.keyWord);
        this.storage.set('historyData', history);
      }
      
    } else {
      if (this.keyWord) {
        this.historyList.push(this.keyWord);
        this.storage.set('historyData',this.historyList);
      }
    }

  }
  getHistory(){
    let history = this.storage.get('historyData');
    if(history){
      this.historyList = history;
    }
  
  }

  removeHistory(item){
    let alert = this.alertCtrl.create({
      title: '您确定要删除吗?',
      message: '您确定删除这条历史记录吗,确定点击是,否则点击否。',
      buttons: [
        {
          text: '否',
          handler: () => {
            console.log('Cancel clicked');
          }
        },
        {
          text: '是',
          handler: () => {
            let index =  this.historyList.indexOf(item);
            this.historyList.splice(index,1);
            this.storage.set('historyData',this.historyList);
          }
        }
      ]
    });
    alert.present();
  }
}


