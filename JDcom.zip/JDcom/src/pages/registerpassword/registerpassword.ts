import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { ConfigProvider } from '../../providers/config/config';
import { HttpServiceProvider } from '../../providers/http-service/http-service';
import { StorageProvider } from '../../providers/storage/storage';

/**
 * Generated class for the RegisterpasswordPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-registerpassword',
  templateUrl: 'registerpassword.html',
})
export class RegisterpasswordPage {
  public tel = '';
  public code = '';
  public password = '';
  public repeatPwd = '';

  constructor(public navCtrl: NavController, public navParams: NavParams,public config : ConfigProvider, public httpService : HttpServiceProvider, public storage: StorageProvider,public toastCtrl: ToastController) {
    this.tel = storage.get('tel');
    this.code = storage.get('code');
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad RegisterpasswordPage');
  }

  register(){
    if(this.password!==this.repeatPwd){
      let toast = this.toastCtrl.create({
        message: '两次密码不一样',
        duration: 3000,
        position: 'top'
      });
    
      toast.onDidDismiss(() => {
        console.log('Dismissed toast');
      });
    
      toast.present();
     }else if(this.password.length <6){
      let toast = this.toastCtrl.create({
        message: '密码长度不能小于6位',
        duration: 3000,
        position: 'top'
      });
    
      toast.onDidDismiss(() => {
        console.log('Dismissed toast');
      });
    
      toast.present();

     }
     else{
     this.httpService.post('api/register',{'tel':this.tel,'code':this.code,'password':this.password},(result)=>{
        if(result.success){
          this.storage.set('userinfo',result.userinfo[0]);
          this.navCtrl.popToRoot();
        }
     });
    }
  }

}
