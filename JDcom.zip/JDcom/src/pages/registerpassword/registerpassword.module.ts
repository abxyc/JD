import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RegisterpasswordPage } from './registerpassword';

@NgModule({
  declarations: [
    RegisterpasswordPage,
  ],
  imports: [
    IonicPageModule.forChild(RegisterpasswordPage),
  ],
})
export class RegisterpasswordPageModule {}
