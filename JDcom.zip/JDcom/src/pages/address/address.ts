import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import { AddAddressPage } from '../add-address/add-address';
import { UtilsProvider } from '../../providers/utils/utils';
import { HttpServiceProvider } from '../../providers/http-service/http-service';
import { EditAddressPage } from '../edit-address/edit-address';

/**
 * Generated class for the AddressPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-address',
  templateUrl: 'address.html',
})
export class AddressPage {
  public AddAddressPage = AddAddressPage;
  public addressList = [];
  public userinfo :any;

HttpServiceProvider
constructor(public navCtrl: NavController, 
            public navParams: NavParams, 
            public utils:UtilsProvider, 
            public httpService: HttpServiceProvider,
            public alertCtrl:AlertController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AddressPage');
  }

  ionViewDidEnter(){
    this.userinfo = this.utils.getUserInfo();
    this.getAddressList();
  }

  addAddress(){
    // this.utils.sign();

  }

  getAddressList(){
    let userinfo :any = this.userinfo;
    let data = {
      uid: userinfo._id,
      salt: userinfo.salt
    }
   let sign = this.utils.sign(data);
   let api = `api/addressList?uid=${userinfo._id}&sign=${sign}`; 
   this.httpService.request(api,(rlst)=>{
     if (rlst.ok) {
       this.addressList = rlst['_body'].result; 
       console.log(this.addressList);     
     } else {
       console.log(rlst.message);
     }

   });
  }

  deleteAddress(key,id){
    let that:any = this;
    let alert = this.alertCtrl.create({
      title: '提示信息',
      message: '您确定要删除吗?',
      buttons: [
        {
          text: '取消',
          handler: () => {
          }
        },
        {
          text: '删除',
          handler: () => {
            that.deleteAddressAction(key,id);
          }
        }
      ]
    });
    alert.present();
  }

  deleteAddressAction(key,address_id){
    let userinfo :any = this.userinfo;
    let data = {
      uid: userinfo._id,
      salt: userinfo.salt,
      id: address_id
    }
    let api = 'api/deleteAddress';
    let sign = this.utils.sign(data);
    this.httpService.post(api,{
      uid: userinfo._id,
      sign: sign,
      id: address_id
    },(rslt)=>{
      if(rslt.success){
        this.addressList.splice(key,1);
      }
    })

  }

  changeAddress(){

  }

  editAddress(item){
    this.navCtrl.push(EditAddressPage,{
      'item':item
    })
  }

}
