import { Component,ViewChild,ElementRef } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ConfigProvider } from '../../providers/config/config';
import { HttpServiceProvider } from '../../providers/http-service/http-service';
import { StorageProvider } from '../../providers/storage/storage';
import { CartPage } from '../cart/cart';

/**
 * Generated class for the ProductdetailPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-productdetail',
  templateUrl: 'productdetail.html',
})
export class ProductdetailPage {
  public tabs = 'plist';
  public item = {};
  public variety = {};
  public num = 1;
  public cartNums = 1;
  @ViewChild('myattr') myattr: ElementRef;

  public CartPage = CartPage;

  constructor(public navCtrl: NavController, public navParams: NavParams, public config: ConfigProvider, public httpService:HttpServiceProvider, public storage: StorageProvider) {
    let id =  this.navParams.get('id');

    this.getProductDetail(id);

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ProductdetailPage');
    this.bindEvent();
  }

  ionViewDidEnter(){
    this.cartNums = this.getCartNums();
  }

  getProductDetail(id){
    let apiUrl =  `api/pcontent?id=${id}`;
    this.httpService.request(apiUrl,(data)=>{
      this.item = data['_body'].result;
      this.variety = this.item['attr'][0];
      console.log(this.variety);
    });

  }

  bindEvent(){
    let attr = this.myattr.nativeElement;
    attr.onclick = (e)=>{
      if(e.srcElement.nodeName == 'SPAN'){
        let ele:any =  e.target;
        let parentNode = ele.parentNode;
        let children = parentNode.children;
        for (let index = 0; index < children.length; index++) {
          children[index].className = ''
        }

        ele.className = 'active';

      }
    }

  }


  increase(){
    this.num ++;

  }

  decrease(){
    if(this.num >1){
      this.num --;
    }

  }

  addCart(){
    let product_title = this.item['title'];
    let product_id  =  this.item['_id'];
    let product_pic = this.item['pic'];
    let product_price =  this.item['price'];
    let product_count =  this.num;
    let product_attr :any = '';

    let activeDom = document.querySelectorAll('#myattr .active');
    for (let index = 0; index < activeDom.length; index++) {
      product_attr+= activeDom[index].innerHTML;    
    }

    let json = {
      'product_title': product_title,
       product_id,
       product_pic,
       product_price,
       product_count,
       product_attr,
       checked: true
    }

    let stroageData = this.storage.get('carts_data');
    if(stroageData){
      if(this.hasData(stroageData,json.product_id)){
        for (let index = 0; index < stroageData.length; index++) {
         if(stroageData[index].product_id == json.product_id){
          stroageData[index].product_count += json.product_count;
         }       
        }
      } else{
        stroageData.push(json);
      }
      this.storage.set('carts_data',stroageData);

    } else{
      let templateArr = [];
      templateArr.push(json);
      this.storage.set('carts_data',templateArr);
    }
    this.cartNums +=json.product_count;
  }


  hasData(stroageData, product_id){
    if (stroageData) {
      for (let index = 0; index < stroageData.length; index++) {
        if (stroageData[index].product_id == product_id) {        
         return true;
        }
       }
    } 
  }

  getCartNums(){
    let stroageData = this.storage.get('carts_data');
    let cartNums = 0;
    if(stroageData){
      for (let index = 0; index < stroageData.length; index++) {
        cartNums += stroageData[index].product_count;
      }
    }
    return cartNums; 

  }

}
