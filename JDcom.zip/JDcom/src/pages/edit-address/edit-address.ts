import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { HttpServiceProvider } from '../../providers/http-service/http-service';
import { UtilsProvider } from '../../providers/utils/utils';



/**
 * Generated class for the EditAddressPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-edit-address',
  templateUrl: 'edit-address.html',
})
export class EditAddressPage {
  public item: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public httpService:HttpServiceProvider,public toastCtrl: ToastController, public utils:UtilsProvider) {
    this.item = this.navParams.get('item');
    console.log(this.item);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad EditAddressPage');
  }

  ionViewDidEnter(){

  }
  editAddress(){
    if (this.item.address!==''&&this.item.name!==''&&this.item.phone!=='') {
      let userinfo = this.utils.getUserInfo();
      let data = {
        id: this.item['_id'],
        uid: userinfo._id,
        salt:userinfo.salt,
        name: this.item.name,
        phone: this.item.phone,
        address: this.item.address
      }
  
      let sign = this.utils.sign(data);
      let api = 'api/editAddress';
      this.httpService.post(api,
        {
          id: this.item['_id'],
          uid: userinfo._id,
          sign:sign,
          name: this.item.name,
          phone: this.item.phone,
          address: this.item.address
        },(rslt)=>{
          if (rslt.success) {
            this.navCtrl.pop();
            
          }
        }
      );
      } else {
        let toast = this.toastCtrl.create({
          message: '收货地址不对',
          duration: 3000,
          position: 'top'
        });
      
        toast.onDidDismiss(() => {
          console.log('Dismissed toast');
        });
      
        toast.present();
        
      }  
  }

}
