import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RegistersignPage } from './registersign';

@NgModule({
  declarations: [
    RegistersignPage,
  ],
  imports: [
    IonicPageModule.forChild(RegistersignPage),
  ],
})
export class RegistersignPageModule {}
