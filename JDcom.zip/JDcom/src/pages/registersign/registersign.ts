import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { RegisterpasswordPage } from '../registerpassword/registerpassword';
import { ConfigProvider } from '../../providers/config/config';
import { HttpServiceProvider } from '../../providers/http-service/http-service';
import { StorageProvider } from '../../providers/storage/storage';


/**
 * Generated class for the RegistersignPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-registersign',
  templateUrl: 'registersign.html',
})
export class RegistersignPage {
  public code ="";
  public isShowSend = false;
  public num = 10;
  public tel = '';

  constructor(public navCtrl: NavController, public navParams: NavParams,public config : ConfigProvider, public httpService : HttpServiceProvider, public storage :StorageProvider,public toastCtrl:ToastController) {
  this.tel = this.storage.get('tel');
  }

  ionViewDidLoad() {
    this.timer();
  }

  goReigisterpasswordPage(){
    this.httpService.post('api/validateCode', {'tel': this.tel,'code':this.code}, (rslt) => {
      if (rslt.success) {
        this.storage.set('code',this.code);
        this.navCtrl.push(RegisterpasswordPage);
      } else {
        let toast = this.toastCtrl.create({
          message: '验证码输入错误',
          duration: 3000,
          position: 'top'
        });
      
        toast.onDidDismiss(() => {
          console.log('Dismissed toast');
        });
      
        toast.present();
      }
    });
   
  }

  timer(){
    let timer = setInterval(()=>{
      -- this.num;
      if(this.num==0){
        clearInterval(timer);
        this.isShowSend = true;
      }
    },1000)

  }

  resend(){

    this.httpService.post('api/sendCode', {'tel': this.tel}, (rslt) => {
      if (rslt.success) {
        this.isShowSend = false;
        this.timer();
        this.num = 10;
      } else {
        alert('发送验证码失败');
      }

    });

  }
}
